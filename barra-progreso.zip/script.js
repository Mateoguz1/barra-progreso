
document.getElementById("inputMonto").addEventListener("input", function () {
  const monto = parseFloat(this.value) || 0;
  const objetivo = 10000;
  const porcentaje = Math.min((monto / objetivo) * 100, 100);

  document.getElementById("barraProgreso").style.width = porcentaje + "%";
  document.getElementById("porcentaje").textContent = Math.round(porcentaje) + "%";
});
